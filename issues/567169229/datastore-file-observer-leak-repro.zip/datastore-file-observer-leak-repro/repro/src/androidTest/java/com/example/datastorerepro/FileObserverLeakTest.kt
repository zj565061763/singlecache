package com.example.datastorerepro

import androidx.datastore.core.MultiProcessDataStoreFactory
import androidx.datastore.core.Serializer
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.produceIn
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FileObserverLeakTest {
    /** The collection of observe(file) is cancelled before its producer starts, so send(Unit) throws */
    @Test
    fun listenerIsReleasedWhenCollectionIsCancelledBeforeProducerStarts() {
        val dir = newDirectory("observer_leak")
        leakListener(File(dir, "data"))
        assertEquals(0, listenerCount(dir))
    }

    /** A leaked listener keeps a stale FileObserver for the directory, which is reused after the directory is recreated */
    @Test
    fun writesFromAnotherProcessAreDeliveredAfterDirectoryIsRecreated(): Unit = runBlocking {
        val dir = newDirectory("observer_recreate")
        val file = File(dir, "data")
        leakListener(file)
        val leaked = listenerCount(dir)

        // The app clears the directory while no DataStore observes it, then uses it again
        dir.deleteRecursively()
        dir.mkdirs()
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        val dataStore = MultiProcessDataStoreFactory.create(serializer = IntSerializer, scope = scope, produceFile = { file })
        val latest = MutableStateFlow<Int?>(null)
        val collector = launch(Dispatchers.IO) { dataStore.data.collect { latest.value = it } }
        // Wait until DataStore registers its own listener and handles the initial event,
        // otherwise that initial event alone makes it re-read the file
        withTimeout(5_000) { while (listenerCount(dir) != leaked + 1) delay(10) }
        delay(200)
        val received = writeUntilReceived(file, 1, latest)

        collector.cancelAndJoin()
        scope.coroutineContext.job.cancelAndJoin()
        assertTrue("leakedListeners=$leaked receivedAfterRecreate=$received", received)
    }

    /** Short collections through the public API hit the same race without any special setup, it is timing dependent */
    @Test
    fun listenersAreReleasedAfterShortCollections(): Unit = runBlocking {
        val dir = newDirectory("observer_short_collections")
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        val dataStore = MultiProcessDataStoreFactory.create(serializer = IntSerializer, scope = scope, produceFile = { File(dir, "data") })

        // Nothing else collects data, so every call starts and stops observing the directory
        var calls = 0
        while (calls < 50_000) {
            dataStore.data.flowOn(Dispatchers.IO).first()
            calls++
            // Listeners still being registered or released settle quickly, a leaked one stays
            if (calls % 500 == 0 && listenerCount(dir) > 0) {
                delay(200)
                if (listenerCount(dir) > 0) break
            }
        }

        scope.coroutineContext.job.cancelAndJoin()
        val remaining = listenerCount(dir)
        assertEquals("calls=$calls remainingAfterDataStoreClosed=$remaining", 0, remaining)
    }
}

private fun newDirectory(name: String): File {
    val context = InstrumentationRegistry.getInstrumentation().targetContext
    return File(context.filesDir, name).apply {
        deleteRecursively()
        mkdirs()
    }
}

/** Cancels a collection of MulticastFileObserver.observe(file) after its producer is scheduled but before it runs */
private fun leakListener(file: File) {
    val executor = Executors.newSingleThreadExecutor()
    val release = CountDownLatch(1)
    // Occupy the only thread so the producer is queued but not started
    executor.execute { release.await() }
    val channel = observe(file).produceIn(CoroutineScope(executor.asCoroutineDispatcher()))
    channel.cancel()
    release.countDown()
    executor.shutdown()
    check(executor.awaitTermination(5, TimeUnit.SECONDS))
}

private object IntSerializer : Serializer<Int> {
    override val defaultValue = 0
    override suspend fun readFrom(input: InputStream): Int = input.readBytes().decodeToString().toIntOrNull() ?: 0
    override suspend fun writeTo(t: Int, output: OutputStream) = output.write(t.toString().encodeToByteArray())
}

// MulticastFileObserver is internal, so it is reached through reflection

@Suppress("UNCHECKED_CAST")
private fun observe(file: File): Flow<Unit> {
    val clazz = Class.forName("androidx.datastore.core.MulticastFileObserver")
    val companion = clazz.getDeclaredField("Companion").apply { isAccessible = true }.get(null)!!
    val method = companion.javaClass.getDeclaredMethod("observe", File::class.java).apply { isAccessible = true }
    return method.invoke(companion, file) as Flow<Unit>
}

/** Listeners registered for [dir], counted the same way as MulticastFileObserverTest checks fileObservers */
private fun listenerCount(dir: File): Int {
    val clazz = Class.forName("androidx.datastore.core.MulticastFileObserver")
    val lock = clazz.getDeclaredField("LOCK").apply { isAccessible = true }.get(null)!!
    val observers = clazz.getDeclaredField("fileObservers").apply { isAccessible = true }.get(null) as Map<*, *>
    return synchronized(lock) {
        val observer = observers[dir.canonicalPath] ?: return 0
        (clazz.getDeclaredField("delegates").apply { isAccessible = true }.get(observer) as List<*>).size
    }
}

/** Repeats the write because the file observer is registered asynchronously */
private suspend fun writeUntilReceived(file: File, value: Int, latest: MutableStateFlow<Int?>): Boolean =
    withTimeoutOrNull(5_000) {
        while (true) {
            writeFromAnotherProcess(file, value)
            if (withTimeoutOrNull(500) { latest.first { it == value } } != null) break
        }
    } != null

/** Writes like another process would: bump the shared version, then rename a new file over the data file */
private fun writeFromAnotherProcess(file: File, value: Int) {
    RandomAccessFile(File(file.path + ".version"), "rw").use { raf ->
        val buffer = raf.channel.map(FileChannel.MapMode.READ_WRITE, 0, Int.SIZE_BYTES.toLong())
        buffer.order(ByteOrder.nativeOrder())
        buffer.putInt(0, buffer.getInt(0) + 1)
    }
    val temp = File(file.path + ".other-${System.nanoTime()}")
    temp.writeText(value.toString())
    check(temp.renameTo(file))
}
