package com.example.datastorerepro

import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.core.MultiProcessDataStoreFactory
import androidx.datastore.core.Serializer
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.CopyOnWriteArrayList
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FailedWriteTest {
    @Test
    fun singleProcessFailedWriteIsNotVisible(): Unit = runBlocking {
        val file = newFile("failed_write_single")
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        val dataStore = DataStoreFactory.create(serializer = IntSerializer, scope = scope, produceFile = { file })
        assertFailedWriteIsNotVisible(file, dataStore)
        scope.coroutineContext.job.cancelAndJoin()
    }

    @Test
    fun multiProcessFailedWriteIsNotVisible(): Unit = runBlocking {
        val file = newFile("failed_write_multi")
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        val dataStore = MultiProcessDataStoreFactory.create(serializer = IntSerializer, scope = scope, produceFile = { file })
        assertFailedWriteIsNotVisible(file, dataStore)
        scope.coroutineContext.job.cancelAndJoin()
    }
}

/** updateData fails because the data file cannot be replaced, the new value must not be visible afterwards */
private suspend fun assertFailedWriteIsNotVisible(file: File, dataStore: DataStore<Int>) = coroutineScope {
    dataStore.updateData { 1 }
    val collected = CopyOnWriteArrayList<Int>()
    val collector = launch(Dispatchers.IO) { dataStore.data.collect { collected += it } }
    withTimeout(5_000) { while (1 !in collected) delay(10) }

    val failure = runCatching {
        dataStore.updateData {
            // A non-empty directory cannot be replaced by the scratch file, so the rename fails
            check(file.delete())
            check(File(file, "blocker").mkdirs())
            2
        }
    }.exceptionOrNull()
    // A failed rename leaves the old data file in place, restore it that way
    check(file.deleteRecursively())
    file.writeText("1")

    // Give the collector time to receive anything emitted by the failed write
    delay(200)
    val dataAfterFailure = dataStore.data.first()
    val seenByNextUpdate = dataStore.updateData { it }
    val dataAfterNextUpdate = dataStore.data.first()
    collector.cancelAndJoin()

    val report = "updateDataThrew=${failure?.javaClass?.simpleName} collected=$collected dataAfterFailure=$dataAfterFailure " +
        "seenByNextUpdate=$seenByNextUpdate dataAfterNextUpdate=$dataAfterNextUpdate"
    assertTrue(
        report,
        failure is IOException && 2 !in collected && dataAfterFailure == 1 && seenByNextUpdate == 1 && dataAfterNextUpdate == 1,
    )
}

private fun newFile(name: String): File {
    val context = InstrumentationRegistry.getInstrumentation().targetContext
    val dir = File(context.filesDir, name).apply {
        deleteRecursively()
        mkdirs()
    }
    return File(dir, "data")
}

private object IntSerializer : Serializer<Int> {
    override val defaultValue = 0
    override suspend fun readFrom(input: InputStream): Int = input.readBytes().decodeToString().toIntOrNull() ?: 0
    override suspend fun writeTo(t: Int, output: OutputStream) = output.write(t.toString().encodeToByteArray())
}
