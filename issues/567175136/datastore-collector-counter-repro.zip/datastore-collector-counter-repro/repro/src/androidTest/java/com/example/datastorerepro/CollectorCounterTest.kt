package com.example.datastorerepro

import androidx.datastore.core.DataStore
import androidx.datastore.core.MultiProcessDataStoreFactory
import androidx.datastore.core.Serializer
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class CollectorCounterTest {
    /** Lost decrements: 64 collectors that have all incremented are cancelled together */
    @Test
    fun cancellingCollectorsTogether() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val file = File(context.filesDir, "collector_counter_together").apply { delete() }
        val dataStore = MultiProcessDataStoreFactory.create(serializer = IntSerializer, produceFile = { file })

        val longLived = launch(Dispatchers.IO) { dataStore.data.collect {} }
        withTimeout(5_000) { while (dataStore.collectorCounter() != 1) delay(10) }

        val counters = List(20) {
            val before = dataStore.collectorCounter()
            val group = launch { repeat(64) { launch(Dispatchers.IO) { dataStore.data.collect {} } } }
            withTimeout(5_000) { while (dataStore.collectorCounter() != before + 64) delay(10) }
            group.cancelAndJoin()
            dataStore.collectorCounter()
        }

        longLived.cancelAndJoin()
        val report = "counters=$counters final=${dataStore.collectorCounter()} " +
            "collectorJobActiveWithoutCollector=${dataStore.collectorJob()?.isActive == true}"
        assertTrue(report, counters.all { it == 1 } && dataStore.collectorCounter() == 0)
    }

    /**
     * Lost increment with an executed decrement. The test holds collectorMutex to stand in for another collector,
     * cancels a collector waiting in incrementCollector(), then releases the mutex.
     */
    @Test
    fun lostIncrementStopsCrossProcessUpdates() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val file = File(context.filesDir, "collector_counter_low").apply { delete() }
        File(file.path + ".version").delete()
        val dataStore = MultiProcessDataStoreFactory.create(serializer = IntSerializer, produceFile = { file })

        val latest = MutableStateFlow<Int?>(null)
        val longLived = launch(Dispatchers.IO) { dataStore.data.collect { latest.value = it } }
        withTimeout(5_000) { while (dataStore.collectorCounter() != 1) delay(10) }

        // Sanity check: a write from "another process" reaches the collector while the counter is right
        val receivedBefore = writeUntilReceived(file, 1, latest)

        val mutex = dataStore.collectorMutex()
        mutex.lock()
        val firstValue = CompletableDeferred<Unit>()
        val victim = launch(Dispatchers.IO) { dataStore.data.collect { firstValue.complete(Unit) } }
        firstValue.await()
        delay(200) // victim is now suspended in incrementCollector()
        victim.cancel()
        mutex.unlock()
        victim.join()

        val counterAfter = dataStore.collectorCounter()
        val jobActiveAfter = dataStore.collectorJob()?.isActive == true
        val receivedAfter = writeUntilReceived(file, 2, latest)

        longLived.cancelAndJoin()
        val report = "receivedBefore=$receivedBefore counterAfter=$counterAfter " +
            "collectorJobActiveAfter=$jobActiveAfter receivedAfter=$receivedAfter"
        assertTrue(report, receivedBefore && counterAfter == 1 && jobActiveAfter && receivedAfter)
    }
}

private object IntSerializer : Serializer<Int> {
    override val defaultValue = 0
    override suspend fun readFrom(input: InputStream): Int = input.readBytes().decodeToString().toIntOrNull() ?: 0
    override suspend fun writeTo(t: Int, output: OutputStream) = output.write(t.toString().encodeToByteArray())
}

// Private fields of DataStoreImpl, read only to make the drift visible
private fun DataStore<*>.collectorCounter(): Int =
    javaClass.getDeclaredField("collectorCounter").apply { isAccessible = true }.getInt(this)

private fun DataStore<*>.collectorJob(): Job? =
    javaClass.getDeclaredField("collectorJob").apply { isAccessible = true }.get(this) as Job?

private fun DataStore<*>.collectorMutex(): Mutex =
    javaClass.getDeclaredField("collectorMutex").apply { isAccessible = true }.get(this) as Mutex

/** Repeats the write because the file observer is registered asynchronously after the counter reaches 1 */
private suspend fun writeUntilReceived(file: File, value: Int, latest: MutableStateFlow<Int?>): Boolean =
    withTimeoutOrNull(5_000) {
        while (true) {
            writeFromAnotherProcess(file, value)
            if (withTimeoutOrNull(500) { latest.first { it == value } } != null) break
        }
    } != null

/** Writes like another process would: bump the shared version, then rename a new file over the data file */
private fun writeFromAnotherProcess(file: File, value: Int) {
    RandomAccessFile(File(file.path + ".version"), "rw").use { raf ->
        val buffer = raf.channel.map(FileChannel.MapMode.READ_WRITE, 0, Int.SIZE_BYTES.toLong())
        buffer.order(ByteOrder.nativeOrder())
        buffer.putInt(0, buffer.getInt(0) + 1)
    }
    val temp = File(file.path + ".other-${System.nanoTime()}")
    temp.writeText(value.toString())
    check(temp.renameTo(file))
}
